from fetch_sequences import fetch_sequences

def main():
    fetch_sequences.main()

if __name__ == "__main__":
    main()