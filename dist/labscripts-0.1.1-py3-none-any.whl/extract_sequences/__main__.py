from extract_sequences.extract_sequences import extractor

def main():
    extractor()

if __name__ == "__main__":
    main()